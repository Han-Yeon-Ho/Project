package com.ebookfrenzy.Together;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static android.content.Context.ALARM_SERVICE;


/**
 * A simple {@link Fragment} subclass.
 */
public class Tab2Fragment extends Fragment {

    private Intent intent;
    private PendingIntent ServicePending;


    private static final int MILLISINFUTURE = 120*1000;//총 시간 (300초 = 5분)
    private static final int COUNT_DOWN_INTERVAL = 1000;//onTick 메소드를 호출할 간격 (1초)

    public TextView countTxt;
    public TextView OTPnum;
    public ImageButton btn;
    private CountDownTimer countDownTimer;
    public static Tab2Fragment mContext;
    public static int count = 120;
    public Tab2Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_tab2, container, false);
        countTxt = (TextView) view.findViewById(R.id.count_txt);
        btn = view.findViewById(R.id.otpcreate);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = Tab2Fragment.count;
                String num = Dlg_changeNum.number1;
                if(count == 120 & num != null )
                {
                    ((Tab2Fragment)Tab2Fragment.mContext).startTimer();
                    ((Tab2Fragment)Tab2Fragment.mContext).retNum();
                } else {
                    if(count < 120)
                        ((Tab2Fragment)Tab2Fragment.mContext).retNum();
                    Toast.makeText(getContext(), "기다리세요", Toast.LENGTH_SHORT).show();

                    if(num == null)
                        Toast.makeText(getContext(), "번호를 입력해주세요", Toast.LENGTH_SHORT).show();

                }
            }
        });

               countTxt = (TextView)view.findViewById(R.id.count_txt);
        mContext = this;
        OTPnum = (TextView)view.findViewById(R.id.OTPnum);



        return view;
    }
    public void startTimer(){
        countDownTimer();
        countDownTimer.start();
    }
    private void countDownTimer() {

        countDownTimer = new CountDownTimer(MILLISINFUTURE, COUNT_DOWN_INTERVAL) {
             // 제한시간
            public void onTick(long millisUntilFinished) {
                countTxt.setText(String.valueOf(count/60) + "분" + String.valueOf(count%60)+ "초" );
                count --;
            }
            public void onFinish() {
                count = 120;
                countTxt.setText(String.valueOf("OTP 만료."));
            }
        };
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        try{
            countDownTimer.cancel();
        } catch (Exception e) {}
        countDownTimer=null;
    }



    public void retNum(){
        int Pw = Integer.parseInt(Dlg_changeNum.number1);
        //일련번호
        int Sn = 4581;

        int[] temp1 = new int [5];
        int[] temp2 = new int [4];
        int[] temp3 = new int [4];


        //일련번호 + 비밀번호, OTP 계산하기
        for(int i=0;i<5;i++)
        {
            temp1[i] = Pw+Sn;

            temp2[0] = (Pw/1000);
            temp2[1] = (Pw-(temp2[0]*1000))/100;
            temp2[2] = (Pw-(temp2[0]*1000)-(temp2[1]*100))/10;
            temp2[3] = (Pw-(temp2[0]*1000)-(temp2[1]*100)-(temp2[2]*10));

            temp3[0] = (Sn/1000);
            temp3[1] = ((Sn-(temp3[0]*1000))/100);
            temp3[2] = (Sn-(temp3[0]*1000)-(temp3[1]*100))/10;
            temp3[3] = (Sn-(temp3[0]*1000)-(temp3[1]*100)-(temp3[2]*10));

            for(int j = 0; j<temp2.length; j++)
            {
                //1씩 증가
                temp2[j] = temp2[j] + 1;
                temp3[j] = temp3[j] + 1;

                if(temp2[j]>=10)
                    temp2[j] = temp2[j] - 10;


                if(temp3[j]>=10)
                    temp3[j] = temp3[j] - 10;


            }
            Pw = (temp2[0]*1000)+(temp2[1]*100)+(temp2[2]*10)+(temp2[3]);
            Sn = (temp3[0]*1000)+(temp3[1]*100)+(temp3[2]*10)+(temp3[3]);


            System.out.println(temp1[i]);


        }




        // 지정해놓은 배열

        int OTPArray[][] = {
                {1,3,4,5,2,1,3,2,3,6,
                        8,4,3,3,7,2,5,7,6,4,
                        7,5,3,7,4,3,9,0,6,2,
                        7,9,4,2,9,4,2,5,7,0,
                        7,4,2,5,6,8,9,4,4,7,
                        4,4,5,2,4,5,2,4,6,8,
                        6,4,1,0,9,4,2,7,4,3,
                        6,8,8,2,4,6,8,9,7,4,
                        3,1,4,6,8,0,4,3,8,0,
                        2,5,3,2,6,8,9,3,6,8},
                {2,4,5,6,8,3,2,7,9,0,
                        3,2,5,6,3,3,5,6,8,8,
                        7,5,7,8,9,7,4,4,3,4,
                        2,5,0,8,7,9,5,3,5,6,
                        0,7,5,2,8,6,3,2,4,8,
                        3,5,8,0,5,3,5,8,3,2,
                        4,7,2,5,2,8,9,4,3,7,
                        2,4,9,2,4,3,4,5,7,8,
                        2,0,8,7,5,5,8,9,0,7,
                        3,9,7,4,6,8,0,1,4,8},

                {1,0,2,9,4,7,3,5,7,8,
                        2,4,3,7,2,3,4,6,1,2,
                        1,3,5,0,2,1,2,5,6,7,
                        7,1,5,7,2,5,9,2,5,0,
                        3,1,5,7,4,9,1,9,4,2,
                        2,5,2,8,3,8,3,7,9,3,
                        0,8,7,5,2,5,6,2,5,8,
                        7,5,4,6,2,4,6,7,8,9,
                        6,5,3,7,0,8,3,0,4,2,
                        2,4,5,6,9,4,2,6,8,3},


                {7,5,3,2,5,7,3,2,6,0,
                        2,5,6,7,3,5,6,7,8,5,
                        2,3,5,7,8,9,0,0,2,5,
                        2,4,5,7,9,0,9,7,3,2,
                        8,7,6,5,4,3,7,8,4,2,
                        2,4,5,1,1,2,4,5,4,5,
                        2,3,4,1,6,7,9,6,4,4,
                        2,1,4,7,5,3,7,4,3,6,
                        0,9,7,5,3,7,2,4,7,6,
                        5,4,1,3,8,6,8,9,6,4},

                {2,3,5,3,2,9,0,8,6,5,
                        2,1,6,4,3,2,6,7,8,9,
                        0,7,4,2,5,8,3,7,1,3,
                        4,2,8,6,5,0,7,5,4,8,
                        2,1,4,5,6,2,7,8,9,3,
                        8,1,9,6,4,7,0,2,4,3,
                        3,0,5,9,3,2,8,4,4,7,
                        0,2,8,3,7,2,7,9,2,4,
                        1,9,2,0,3,7,4,0,7,6,
                        0,3,2,6,4,8,2,6,3,5},

                {2,4,7,6,4,2,0,5,2,4,
                        7,5,3,9,4,3,2,5,7,8,
                        1,5,8,4,2,6,0,8,0,4,
                        8,3,2,5,6,8,8,2,1,2,
                        4,2,3,4,6,2,4,7,5,7,
                        9,3,5,7,2,1,9,5,3,5,
                        5,3,6,7,6,7,1,7,2,1,
                        6,8,5,1,1,5,2,9,1,2,
                        3,7,9,1,3,5,7,4,3,5,
                        5,0,7,1,2,5,3,6,8,5},

                {7,6,9,6,0,8,1,2,4,8,
                        3,5,8,5,9,0,7,1,2,7,
                        9,3,2,6,3,6,9,0,6,4,
                        9,8,6,4,2,2,4,6,1,4,
                        7,5,3,6,7,2,6,0,5,4,
                        1,2,5,8,2,0,6,4,2,8,
                        3,5,7,8,9,0,2,7,4,3,
                        3,7,5,8,0,3,3,9,4,8,
                        5,7,3,0,6,7,3,8,3,3,
                        8,6,0,9,3,8,4,3,0,5},

                {8,2,9,3,4,7,5,2,9,4,
                        7,5,9,3,7,9,8,4,5,7,
                        0,9,2,5,7,3,3,9,7,1,
                        4,5,7,9,8,4,5,7,9,0,
                        2,4,7,5,9,0,8,7,5,2,
                        0,3,9,4,7,2,0,4,9,0,
                        4,5,7,2,4,5,6,2,9,3,
                        8,7,5,9,2,0,2,3,9,8,
                        4,5,7,0,2,9,7,8,5,5,
                        7,3,9,4,5,0,1,9,5,7},

                {9,2,3,4,5,1,0,9,8,5,
                        0,3,2,4,5,0,9,8,1,7,
                        9,8,5,7,2,0,3,8,5,0,
                        5,7,4,9,2,0,9,4,5,7,
                        2,9,4,8,5,7,2,9,4,8,
                        5,7,2,0,9,4,8,5,7,2,
                        9,0,4,8,5,7,2,8,5,9,
                        7,1,9,0,5,8,1,5,8,4,
                        7,4,9,4,5,7,9,4,5,9,
                        0,4,8,5,7,2,9,0,5,1},

                {9,0,3,0,9,1,0,3,9,4,
                        0,9,8,0,7,9,9,8,7,9,
                        2,8,3,7,5,9,0,2,8,5,
                        4,7,8,5,6,1,8,5,3,4,
                        9,5,1,0,9,8,5,2,9,8,
                        6,0,2,4,9,0,1,8,7,7,
                        0,9,1,2,6,8,7,5,8,9,
                        1,7,9,3,8,9,7,7,9,8,
                        9,3,4,9,0,2,3,3,4,8,
                        4,9,0,2,8,5,4,7,8,9} };
        //더한 값 나열하기
        String arr;
        long time = System.currentTimeMillis()/1000/60 - 25773120;
        BigInteger bigtime = BigInteger.valueOf(time);
        arr = Integer.toString(temp1[0])+ Integer.toString(temp1[1]) + Integer.toString(temp1[2]) + Integer.toString(temp1[3]) + Integer.toString(temp1[4]);

        BigInteger bignum = new BigInteger(arr);

        bignum = bignum.add(bigtime);

        arr = bignum.toString();

        //문자열 끊기
        String aa = arr.substring(arr.length()-3, arr.length());//시작 : 끝에서 3번째 자리 , 끝 :마지막 자리
        String bb = arr.substring(arr.length()-6, arr.length()-3);
        String cc = arr.substring(arr.length()-9, arr.length()-6);
        String dd = arr.substring(arr.length()-12, arr.length()-9);
        String ee = arr.substring(arr.length()-15, arr.length()-12);
        String ff = arr.substring(arr.length()-18, arr.length()-15);



        // 좌표 추출
        int aX = Integer.parseInt(aa.substring(0,1));
        int aY = Integer.parseInt(aa.substring(1,3));
        int bX = Integer.parseInt(bb.substring(0,1));
        int bY = Integer.parseInt(bb.substring(1,3));
        int cX = Integer.parseInt(cc.substring(0,1));
        int cY = Integer.parseInt(cc.substring(1,3));
        int dX = Integer.parseInt(dd.substring(0,1));
        int dY = Integer.parseInt(dd.substring(1,3));
        int eX = Integer.parseInt(ee.substring(0,1));
        int eY = Integer.parseInt(ee.substring(1,3));
        int fX = Integer.parseInt(ff.substring(0,1));
        int fY = Integer.parseInt(ff.substring(1,3));

        //좌표 대입
        int realA = OTPArray [aX][aY];
        int realB = OTPArray [bX][bY];
        int realC = OTPArray [cX][cY];
        int realD = OTPArray [dX][dY];
        int realE = OTPArray [eX][eY];
        int realF = OTPArray [fX][fY];


        //좌표값 나열

        String result=""+realA;
        result+=realB;
        result+=realC;
        result+=realD;
        result+=realE;
        result+=realF;


        // 최종 결과
        int OTP = (((int )time + Integer.parseInt(result)) )% 1000000;
        if(OTP < 100000)
            OTPnum.setText("0"+OTP+"입니다.");
        else OTPnum.setText(OTP+"입니다.");
        Log.w("otppp", "" + OTP);

    }

}
