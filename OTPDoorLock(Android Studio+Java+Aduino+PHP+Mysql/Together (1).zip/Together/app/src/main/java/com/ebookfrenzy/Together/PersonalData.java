package com.ebookfrenzy.Together;

public class PersonalData {
    private String member_type;
    private String member_time;

    public String getMember_type() {
        return member_type;
    }

    public String getMember_time() {
        return member_time;
    }


    public void setMember_type(String member_type) {
        this.member_type = member_type;
    }

    public void setMember_time(String member_time) {
        this.member_time = member_time;
    }

}