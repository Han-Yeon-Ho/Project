package com.ebookfrenzy.Together;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 */
public class Dlg_version extends Dialog  {
    private static final int LAYOUT = R.layout.fragment_dlg_version;


    public Dlg_version(@NonNull Context context) {
        super(context);
    }

    public Dlg_version(Context context, String name) {
        super(context);
    }

    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(LAYOUT);
        text = findViewById(R.id.explain);

        text.setText("\n처음 시작시 A MODE, B MODE 설정\n\n" +
                "A MODE : 일반적인 비밀번호 입력 \n\n" +
                "B MODE : OTP 번호 입력\n\n" +
                "C MODE : MODE 초기화\n\n" +
                "* 버튼 : 입력된 비밀번호 초기화\n\n" +
                "어플 상단 버튼클릭 시 OTP 번호 생성\n\n" +
                "첫번째 화면 : 출입시간, 출입방법 확인\n\n " +
                "두번째 화면 : OTP 번호 확인\n\n "+
                "세번째 화면 : 번호설정, 방법설명, 고객센터 ");
    }

}
