package com.ebookfrenzy.Together;

/**
 * Created by xldzm on 2018-06-10.
 */


import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class removeActivity extends Activity {

    private Intent intent;
    private PendingIntent ServicePending;
    private AlarmManager alarmManager;
    String number, address;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_remove);
        DataBase db = new DataBase(this, "Together.db", null, 1);
        SQLiteDatabase dbs = db.getWritableDatabase();
        final Cursor cursor = dbs.rawQuery("select * from TOGETHER", null);
        if (cursor.getCount() > 0) {
            cursor.moveToLast();
            address = cursor.getString(3);
        }

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        try {
            SharedPreferences pref = getSharedPreferences("pref", Context.MODE_PRIVATE);
            number = pref.getString("data", null);
            sendSMS(number, address);
           // Toast.makeText(this, "SMS 발송 완료", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        //알람 설정, 해제 버튼
        Button.OnClickListener bClickListener = new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.removeAlarm:
                        removeAlarm();
                        finish();
                        break;
                }
            }

        };

      //  findViewById(R.id.changeSet).setOnClickListener(bClickListener);
        findViewById(R.id.removeAlarm).setOnClickListener(bClickListener);
    }
    private void sendSMS(String phoneNumber, String message) {
        String SENT = "SMS_SENT";
        String DELIVERED = "SMS_DELIVERED";
        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0,
                new Intent(SENT), 0);
        PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0,
                new Intent(DELIVERED), 0);
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, sentPI, deliveredPI);
    }
    void removeAlarm(){
        intent = new Intent("AlarmReceiver");
        //PendingIntent.getBroadcast(Context context, int requestCod, Intent intent, int flag);
        ServicePending = PendingIntent.getBroadcast(removeActivity.this, 111, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        Log.d("ServicePending : ",""+ServicePending.toString());
        Toast.makeText(getBaseContext(), "알람 해제", Toast.LENGTH_SHORT).show();
        alarmManager.cancel(ServicePending);
    }
}

