package com.ebookfrenzy.Together;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Tab3Fragment extends Fragment implements View.OnClickListener {



    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_tab3, container, false);
        Button name = (Button) view.findViewById(R.id.btn1);
        Button version = (Button) view.findViewById(R.id.btn2);
        Button center = (Button) view.findViewById(R.id.btn3);
        name.setOnClickListener(this);
        version.setOnClickListener(this);
        center.setOnClickListener(this);

        return view;

    }


    @Override

    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btn1:
                Dlg_changeNum dialog = new Dlg_changeNum(getActivity());
                dialog.show();
                break;
            case R.id.btn2:
                Dlg_version dlg_version = new Dlg_version(getActivity());
                dlg_version.show();
                dlg_version.setCanceledOnTouchOutside(true);
                break;
            case R.id.btn3:
                Dlg_setting dlg_setting = new Dlg_setting(getActivity());
                dlg_setting.setCanceledOnTouchOutside(true);
                dlg_setting.show();
                break;

        }

    }


}


