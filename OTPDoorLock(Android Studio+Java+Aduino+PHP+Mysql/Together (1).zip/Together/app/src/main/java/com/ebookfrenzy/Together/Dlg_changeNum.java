package com.ebookfrenzy.Together;


import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class Dlg_changeNum extends Dialog implements View.OnClickListener{
    private static final int LAYOUT = R.layout.fragment_dlg_changenum;

    private Context context;

    private TextInputEditText emailEt;

    private TextView cancel;
    private TextView change;

    public static String number1;


    public Dlg_changeNum(@NonNull Context context) {
        super(context);
        this.context = context;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(LAYOUT);

        emailEt = (TextInputEditText) findViewById(R.id.findPwDialogEmailEt);

        cancel = (TextView) findViewById(R.id.cancel);
        change = (TextView) findViewById(R.id.change);

        cancel.setOnClickListener(this);
        change.setOnClickListener(this);
//            if (number1 == null) {
//                Toast.makeText(getContext(), "번호를 먼저 입력해주세요.", Toast.LENGTH_LONG).show();
//            } else {
//                retNum();
//            }


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cancel:
                Toast.makeText(getContext(),"취소.",Toast.LENGTH_LONG).show();
                cancel();
                break;
            case R.id.change:

                number1 = emailEt.getText().toString();
                SharedPreferences pref = getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = pref.edit();
                editor.putString("data", number1);
                editor.commit();

                Toast.makeText(getContext(),number1 + "으로 변경되었습니다.",Toast.LENGTH_LONG).show();
                cancel();
                break;
        }

    }


}